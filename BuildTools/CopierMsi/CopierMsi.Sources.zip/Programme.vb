Imports System.IO
Imports System.Reflection

Module Programme

    Sub Main(ByVal args As String())

        Try
            Select Case args.Length
                Case 2, 3
                    Dim cheminCompletSourceMsi As String = args(0)
                    Dim cheminDestinationMsi As String = args(1)
                    Dim cheminCompletDestinationMsi As String
                    Dim nomFichierSourceMsi As String = Path.GetFileName(cheminCompletSourceMsi)
                    If args.Length = 3 Then
                        Dim chaineARemplacer As String = args(2)
                        If Not nomFichierSourceMsi.Contains(chaineARemplacer) Then
                            Throw New Exception(String.Format( _
                                        "Le nom du fichier original '{0}' ne contient pas la chaine � remplacer '{1}'.", _
                                        nomFichierSourceMsi, _
                                        chaineARemplacer))
                        End If

                        Dim numeroVersion As String = ObtenirNumeroVersion(cheminCompletSourceMsi)
                        cheminCompletDestinationMsi = Path.Combine( _
                                    cheminDestinationMsi, _
                                    nomFichierSourceMsi.Replace(chaineARemplacer, numeroVersion))
                    Else
                        cheminCompletDestinationMsi = Path.Combine( _
                                    cheminDestinationMsi, _
                                    nomFichierSourceMsi)
                    End If
                    Directory.CreateDirectory(cheminDestinationMsi)
                    File.Copy(cheminCompletSourceMsi, cheminCompletDestinationMsi, True)

                Case Else
                    Dim nomExecutable As String = Path.GetFileName(Assembly.GetEntryAssembly().Location)
                    Console.WriteLine("usage: {0} <source MSI> <repertoire destination> [<chaine � remplacer par num�ro de version>]", nomExecutable)
                    Console.WriteLine("exemple: {0} MonMsi_v.X.X.X.msi MaDestination X.X.X", nomExecutable)
            End Select

        Catch ex As Exception
            Console.WriteLine("Erreur: {0}", ex)
        End Try
    End Sub

    Function ObtenirNumeroVersion(ByVal nomMsi As String) As String

        ' On utilise le mode "Late Binding" sur l'objet Installer car il y a un
        ' bug lorsqu'ont utilse le early binding (i.e. CreateObject retourne toujours une erreur)
        Dim installer As Object = CreateObject("WindowsInstaller.Installer")

        Const msiOpenDatabaseModeReadOnly As Integer = 0
        Dim database As Object = installer.OpenDatabase(nomMsi, msiOpenDatabaseModeReadOnly)

        Dim view As Object
        view = database.OpenView("SELECT `Property`,`Value` FROM `Property`")
        view.Execute()

        Dim record As Object
        record = view.Fetch()

        Dim numeroVersion As String = Nothing
        While Not record Is Nothing
            Dim nom As String = record.StringData(1)
            Dim valeur As String = record.StringData(2)
            If String.Compare("ProductVersion", nom, StringComparison.InvariantCultureIgnoreCase) = 0 Then
                numeroVersion = valeur
            End If

            record = view.Fetch()
        End While
        view.Close()

        If numeroVersion Is Nothing Then
            Throw New Exception("Le msi ne contient pas de propri�t� ayant le nom 'ProductVersion'.")
        End If

        Return numeroVersion
    End Function

End Module
